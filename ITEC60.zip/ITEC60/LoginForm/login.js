    function validateForm() {
        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;
    
        if (username.trim() !== "" && password.trim() !== ""){
            if (username === "admin" && password === "admin"){
                window.location.href = "success.html";
                return true;    
            }
            else {
                alert("Invalid username or password");
                return false;
            }
        }
        else {
            alert("Please enter a username and password");
            return false;  
        }
    }
    