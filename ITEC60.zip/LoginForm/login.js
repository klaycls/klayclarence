function validateForm() {
    // var username = document.forms["loginForm"]["username"].value;
    // var password = document.forms["loginForm"]["password"].value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;

    if (username.trim() !== "" && password.trim() !== ""){
        if (username === "username" && password === "password"){
            alert("Login Succesfully!")

            window.location.href = "login.html";
        }
        else alert("Login Successful!");
    }
  }