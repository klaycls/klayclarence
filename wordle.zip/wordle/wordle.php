<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<html>
    <head>
        <title>Play Codle!</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale = 2.0">

        <link rel="stylesheet" href="wordle.css">
        <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
        <script p src="wordle.js"></script>
    </head>

    <body>
        <br>
        <div class="container">

            <div class="content">
                <h3>Welcome, <span><?php echo $_SESSION['user_name'] ?></span></h3>
                <a style="display: inline-block; padding: 10px 30px; background: #333; color: white; margin: 0px 5px; text-decoration: none; border-radius: 15px;" href="login_form.php" class="btn">Switch Account</a>
                <a style="display: inline-block; padding: 10px 30px; background: #333; color: white; margin: 0px 5px; text-decoration: none; border-radius: 15px;" href="register_form.php" class="btn">Sign Up</a>
                <a style="display: inline-block; padding: 10px 30px; background: #333; color: white; margin: 0px 5px; text-decoration: none; border-radius: 15px;" href="logout.php" class="btn">Log Out</a>
            </div>

        </div>
        <br>
        <h1 id="title">Word Game - Codle</h1>
        <caption> Guess any 5 letter word about <b><u>coding</u></b>, you have 6 tries!</caption>
        <br>
        <caption> Program made by: <u>Samala, Cuartero, & Solosa</u></caption>
        <br>
        <br>
        <caption> Guidelines for the game: </caption>
        <br>
        <img src="directions.png">
        <br>
        <hr>
        <br>
        <div id="board">
        </div>
        <br>
        <hr>    
        <h1 id="answer"></h1>

    </body>
</html>
